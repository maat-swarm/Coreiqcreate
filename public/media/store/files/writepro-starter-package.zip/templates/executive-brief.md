# Executive Brief Template

## Problem Statement

## Architecture & Proposed Solution

## Milestones & Deliverables
